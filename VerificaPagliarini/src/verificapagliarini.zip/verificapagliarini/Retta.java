/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificapagliarini;

/**
 *
 * @author studente
 */
public class Retta {
    
    protected double a1,b1,c1;
    
    public Retta(double a , double b, double c) {
        this.a1 = a;
        this.b1 = b;
        this.c1 = c;
    }
    
    public String getTipo(){
        if((a1!=0)&&(b1!=0)){
        return "OBLIQUA";
        }
        if(a1==0){
            return "ORIZZONTALE";
        }
        if(b1==0){
            return "VERTICALE";
        }
        return null;
    }
    
    public String stampa(){
        return "Equazione: " + a1 + "x" + b1 +"y"+ c1 +"= 0";
    }
    public boolean appartiene(double x, double y){
        double tot= a1*x+b1*y+c1;
        if (tot==0){
           return true; 
        }
        else
            return false;
    }
}

